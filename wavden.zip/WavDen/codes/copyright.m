                Gaussian Wavelet Denoising Software
                       (GaussianWaveDen)
                
                     COPYRIGHT 2000-2001

      by Anestis Antoniadis, Jeremie Bigot & Theofanis Sapatinas

Permission to use, copy, modify, and distribute "GaussianWaveDen" 
software for any purpose without fee is hereby granted, provided 
that this entire notice is included in all copies of any software 
which is or includes a copy or modification of this software and in 
all copies of the supporting documentation for such software.

This software is being provided "as is", without any express or 
implied warranty.  In particular, the authors do not make any
representation or warranty of any kind concerning the merchantability
of this software or its fitness for any particular purpose.
